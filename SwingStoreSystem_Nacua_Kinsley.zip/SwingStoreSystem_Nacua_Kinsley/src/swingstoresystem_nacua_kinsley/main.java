
package swingstoresystem_nacua_kinsley;
public class main {
    public static void main(String[] args) {
        new StoreTransactionFrame().setVisible(true);
    }
    
}
