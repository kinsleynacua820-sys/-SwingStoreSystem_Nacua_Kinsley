
package swingstoresystem_nacua_kinsley;

public class StoreData {
    
    public static String[] productNames = {"Rice", "Sugar", "Coffee", "Milk"};
    public static double[] productPrices = {50.0, 45.0, 120.0, 80.0};
    public static int[] inventoryStock = {20, 20, 20, 20};

    public static String[] transProductNames = new String[100];
    public static int[] transQuantities = new int[100];
    public static double[] transTotals = new double[100];

    public static int transactionCount = 0;
    
}
